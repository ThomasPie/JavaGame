package model;


import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Thomas on 5/07/2017.
 */
public class Model {
    private List<String> questionAsked = new ArrayList<>();
    private List<String> possibleSolutions = new ArrayList<>();
    private int currentQuestionIndex = 0;

    public void leesBestand() {
        String[] ss = new String[15];

        try (BufferedReader reader = new BufferedReader(new FileReader("src/tekstbestanden/Opgave1.txt"))) {
            String line = null;
            while ((line = reader.readLine()) != null) {
                line = line.replaceAll("\t","\n");
                ss = line.split("\n");
                for (int i = 0; i < ss.length ; i++) {
                    if((i%2)==0){
                        questionAsked.add(ss[i]);
                    } else{
                        possibleSolutions.add(ss[i]);
                    }
                }
            }
        } catch (IOException ex) {
            System.out.println("No file");
        }
    }


    public void checkValidAnswer(String answer) {
        if (possibleSolutions.get(currentQuestionIndex).equals(answer)) {
            System.out.println("juist");
            //goed geluid afspelen
            Media correctSound = new Media(new File("src/geluidbestanden/CorrectSoundEffect.mp3").toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(correctSound);
            mediaPlayer.play();
        } else {
            System.out.println("fout");
            //fout geluid afspelen
            Media incorrectSound = new Media(new File("src/geluidbestanden/IncorrectSoundEffect.mp3").toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(incorrectSound);
            mediaPlayer.play();
        }
        currentQuestionIndex++;

    }

    public List<String> getQuestionAsked() {
        return this.questionAsked;
    }

    public List<String> getPossibleSolutions() {
        return this.possibleSolutions;
    }

    public int getCurrentQuestionIndex() {
        return currentQuestionIndex;
    }
}

