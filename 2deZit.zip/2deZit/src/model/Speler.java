package model;

/**
 * Created by Thomas on 7/08/2017.
 */
public class Speler {
    public String naam;

    public Speler(String naam) {
        this.naam = naam;
    }

    public String getNaam() {
        return naam;
    }
}
