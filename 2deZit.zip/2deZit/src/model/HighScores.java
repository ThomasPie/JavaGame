package model;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * Created by Thomas on 9/08/2017.
 */
public class HighScores {
    private ArrayList<Score> scores;
    private static final String FILE = "highscores.txt";
    private static final int AANTALSCORES = 10;

    public HighScores() {
        scores = new ArrayList<Score>();
    }

    public void loadHighscore(){
        Path path = Paths.get(FILE);
        Scanner scanner = null;
        try {
            scanner = new Scanner(path);
            int counter = 0;
            while (scanner.hasNext() && counter<10) {
                String[] record = scanner.nextLine().split(":");
                String player = record[0];
                int score = Integer.parseInt(record[1]);
                scores.add(new Score(player,score));
                counter++;
            }
            scores.sort(Score::compareTo);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveScore(){
        try(PrintWriter out = new PrintWriter(FILE)  ){
            for (Score score : scores) {
                out.println(score.getPlayer() + ":" + score.getScore() );
            }
        }
        catch (IOException e){
            e.printStackTrace();
            e.getMessage();
        }
    }

    public static int getAANTALSCORES() {
        return AANTALSCORES;
    }

    public ArrayList<Score> getScores() {
        return scores;
    }

    public boolean addHighscore(Score score){
        ArrayList<Score> oldScores = scores;
        scores.add(score);
        scores.sort(Score::compareTo);
        Collections.sort(scores);
        System.out.println(scores);
        if(scores.size() >= AANTALSCORES){
            scores.remove(scores.size()-1);
        }
        System.out.println(scores);
        saveScore();
        return (!oldScores.equals(scores));
    }
}
