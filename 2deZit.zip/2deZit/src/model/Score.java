package model;

/**
 * Created by Thomas on 9/08/2017.
 */
public class Score implements Comparable<Score> {
    private String player;
    private int score;

    public Score(String player, int score) {
        this.player = player;
        this.score = score;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getPlayer() {
        return player;
    }

    public int getScore() {
        return score;
    }

    @Override
    public int compareTo(Score o) {
        int a = this.getScore();
        int b = o.getScore();

        if (a > b){
            return +1;
        }else if (a < b){
            return -1;
        }else{
            return 0;
        }
    }
}
