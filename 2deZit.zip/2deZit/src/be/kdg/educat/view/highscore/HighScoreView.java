package be.kdg.educat.view.highscore;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextAlignment;
import be.kdg.educat.model.HighScores;

/**
 * Created by Thomas on 9/08/2017.
 */
public class HighScoreView extends VBox {
    private Label finalScore;
    private Label[] highScoresLbl = new Label[10];
    private HighScores highScores;

    public HighScoreView(String name){
        this.highScores = new HighScores();
        highScores.saveHighscore(name);
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes(){
        this.finalScore = new Label("Highscores");
        finalScore.setId("FF");
        int maxLoop = Math.min(10, highScores.getScores().size());
        for (int i = 0; i < maxLoop; i++) {
            highScoresLbl[i] = new Label((i+1) + ". " + highScores.getScores().get(i).toString());
        }
        for (int i = maxLoop; i < 10; i++) {
            highScoresLbl[i] = new Label("<empty>");
        }
    }

    private void layoutNodes(){
        HBox hbox = new HBox();
        hbox.getChildren().add(finalScore);
        finalScore.setAlignment(Pos.CENTER);
        finalScore.setPrefSize(500,40);
        this.getChildren().add(hbox);
        hbox.setAlignment(Pos.CENTER);

        for (int i = 0; i < highScoresLbl.length; i++) {
            highScoresLbl[i].setAlignment(Pos.CENTER);
            highScoresLbl[i].setTextAlignment(TextAlignment.JUSTIFY);
            highScoresLbl[i].setPrefSize(150,40);
        }
        this.setSpacing(20);
        this.setPadding(new Insets(20));

        this.getChildren().addAll(highScoresLbl);
        this.setStyle("-fx-background-color: black");
        this.setAlignment(Pos.CENTER);
    }
}
