package be.kdg.educat.view.highscore;

/**
 * Created by Thomas on 9/08/2017.
 */
public class HighScorePresenter {
    HighScoreView view;

    public HighScorePresenter(HighScoreView view) {
        this.view = view;
    }
}
