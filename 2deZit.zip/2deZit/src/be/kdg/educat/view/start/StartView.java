package be.kdg.educat.view.start;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Created by Thomas on 7/08/2017.
 */
public class StartView extends VBox {
    private Label nameLbl;
    private TextField playerName = new TextField();
    private final ToggleGroup tgGroup = new ToggleGroup();
    private ToggleButton btnContinents = new ToggleButton();
    private ToggleButton btnCapital = new ToggleButton();
    private ToggleButton btnCurrency = new ToggleButton();
    private Button btnBegin;
    private Button btnHighScore;


    public StartView() {
        initialiseNodes();
        layoutnodes();
    }

    private void initialiseNodes() {
        nameLbl = new Label("Name");
        btnBegin = new Button("Begin the game!");
        playerName.setEditable(true);
        btnContinents = new ToggleButton("Continents");
        btnContinents.setUserData(1);
        btnContinents.setToggleGroup(tgGroup);

        btnCapital = new ToggleButton("Capitals");
        btnCapital.setUserData(2);
        btnCapital.setToggleGroup(tgGroup);

        btnCurrency = new ToggleButton("Currencies");
        btnCurrency.setUserData(3);
        btnCurrency.setToggleGroup(tgGroup);
        btnHighScore = new Button("Highscores");
    }

    private void layoutnodes() {
        this.setStyle("-fx-background-color: black");
        this.setAlignment(Pos.CENTER);

        HBox hBox = new HBox();
        hBox.getChildren().addAll(nameLbl, playerName);
        hBox.setSpacing(30);
        hBox.setPadding(new Insets(50));
        hBox.setAlignment(Pos.CENTER);


        HBox hBox1 = new HBox();
        hBox1.getChildren().addAll(btnContinents,btnCapital,btnCurrency);
        hBox1.setSpacing(10);
        hBox1.setPadding(new Insets(20));
        btnContinents.setPrefSize(100,50);
        btnCapital.setPrefSize(100,50);
        btnCurrency.setPrefSize(100,50);
        hBox1.setAlignment(Pos.CENTER);

        HBox hBox2 = new HBox();
        hBox2.getChildren().add(btnBegin);
        hBox2.setPadding(new Insets(20));
        hBox2.setAlignment(Pos.CENTER);

        HBox hBox3 = new HBox();
        hBox3.getChildren().add(btnHighScore);
        hBox3.setPadding(new Insets(10));
        hBox3.setAlignment(Pos.CENTER);

        this.getChildren().addAll(hBox, hBox1,hBox2, hBox3);
    }

    TextField getPlayerName() {
        return playerName;
    }

    ToggleGroup getTgGroup() {
        return tgGroup;
    }

    Button getBtnBegin() {
        return btnBegin;
    }

    Button getBtnHighScore() {
        return btnHighScore;
    }
}
