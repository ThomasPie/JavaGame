package be.kdg.educat.view.start;

import be.kdg.educat.view.highscore.HighScorePresenter;
import be.kdg.educat.view.highscore.HighScoreView;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Toggle;
import be.kdg.educat.model.Model;
import be.kdg.educat.view.game.GamePresenter;
import be.kdg.educat.view.game.GameView;
import javafx.stage.WindowEvent;

/**
 * Created by Thomas on 7/08/2017.
 */
public class StartPresenter {
    private Model model;
    private StartView startView;
    private  GamePresenter gamePresenter;
    private boolean validName;

    public StartPresenter(Model model, StartView startView) {
        this.model = model;
        this.startView = startView;
        this.validName = false;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers(){
        startView.getPlayerName().textProperty().addListener(((observable, oldValue, newValue) -> {
            if(startView.getPlayerName().equals("")){
                validName = false;
            } else{
                validName = true;
            }
            StartPresenter.this.updateView();
        }));

        startView.getTgGroup().selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue) {
                if (newValue != null) {
                    int filechosen = (int) startView.getTgGroup().getSelectedToggle().getUserData();
                    model.setFilechosen(filechosen);
                }
            }
        });

        startView.getBtnBegin().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                GameView gameView = new GameView(startView.getPlayerName().getText());
                GamePresenter gamePresenter = new GamePresenter(gameView);
                gameView.getStylesheets().add("be/kdg/educat/css/Style1.css");
                startView.getScene().setRoot(gameView);
                gamePresenter.getTimeline().play();
            }
        });

        startView.getBtnHighScore().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                HighScoreView highScoreView = new HighScoreView(startView.getPlayerName().toString());
                HighScorePresenter presenter = new HighScorePresenter(highScoreView);
                highScoreView.getStylesheets().add("be/kdg/educat/css/Highscore.css");
                startView.getScene().setRoot(highScoreView);
            }
        });
    }

    private void updateView(){
        this.startView.getBtnBegin().setDisable(!this.validName);
    }

    public void addWindowEventHandlers(){
        startView.getScene().getWindow().setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent event) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setHeaderText("Exit game?");
                alert.setTitle("Warning!");
                alert.getButtonTypes().clear();
                ButtonType yes = new ButtonType("Yes");
                ButtonType no = new ButtonType("No");
                alert.getButtonTypes().addAll(yes,no);
                alert.showAndWait();
                if(alert.getResult().equals(no)){
                    event.consume();
                }
            }
        });
    }
}
