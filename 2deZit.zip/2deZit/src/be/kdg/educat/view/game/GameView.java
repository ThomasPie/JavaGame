package be.kdg.educat.view.game;

import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import be.kdg.educat.model.Model;

import java.util.Random;


/**
 * Created by Thomas on 5/07/2017.
 */
public class GameView extends BorderPane {
    private Button[] statement;
    private Label questionLbl = new Label();
    private Label scoreLbl = new Label();
    private Label timeLbl = new Label();
    private Label playerNameLbl = new Label();
    private Random random = new Random();
    private Pane pane = new Pane();


    public GameView(String name) {
        this.playerNameLbl = new Label(name);
        this.initialiseNodes();
        this.layoutNodes();
        animate();
    }

    private void initialiseNodes() {
        Model model = Model.getInstance();
        model.leesBestand();
        statement = new Button[model.getPossibleSolutions().size()];
        for (int i = 0; i < statement.length; i++) {
            this.statement[i] = new Button(model.getPossibleSolutions().get(i));
        }
        this.questionLbl = new Label(model.getQuestionAsked().get(model.getCurrentQuestionIndex()));
        this.scoreLbl = new Label();
        this.timeLbl = new Label();
        pane.setId("pane");

    }

    private void layoutNodes() {
        //height(y) of pane = 475
        //width(x) of pane = 735
        pane.setLayoutX(735);
        pane.setLayoutY(475);
        //pane.setStyle("-fx-background-image: url("));
        for (int i = 0; i < statement.length; i++) {
            double randX = random.nextInt(735);
            double randY = random.nextInt(475);
            statement[i].setLayoutX(randX);
            statement[i].setLayoutY(randY);
        }
        pane.getChildren().addAll(statement);
        this.setCenter(pane);

        HBox hbox = new HBox();
        hbox.setPadding(new Insets(20));
        hbox.setStyle("-fx-background-color: black");
        hbox.setSpacing(10);
        hbox.getChildren().add(playerNameLbl);
        hbox.getChildren().add(scoreLbl);
        hbox.getChildren().add(timeLbl);
        playerNameLbl.setPrefSize(100, 40);
        scoreLbl.setPrefSize(100, 40);
        timeLbl.setPrefSize(100, 40);
        playerNameLbl.setAlignment(Pos.CENTER);
        scoreLbl.setAlignment(Pos.CENTER);
        timeLbl.setAlignment(Pos.CENTER);
        hbox.setAlignment(Pos.BASELINE_CENTER);
        this.setTop(hbox);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20));
        hbox1.setStyle("-fx-background-color: black");
        hbox1.setSpacing(100);
        hbox1.getChildren().add(questionLbl);
        questionLbl.setPrefSize(320, 40);
        questionLbl.setAlignment(Pos.CENTER);
        hbox1.setAlignment(Pos.BASELINE_CENTER);
        this.setBottom(hbox1);
    }

    private void animate(){
        for (int i = 0; i < getStatement().length; i++) {
            int r = random.nextInt(100);
            int finalI = i;
            final Timeline loop = new Timeline(new KeyFrame(Duration.millis(random.nextInt(r)+8), new EventHandler<ActionEvent>() {
                double deltax = 1;
                double deltay = 1;

                @Override
                public void handle(ActionEvent event) {
                    statement[finalI].setLayoutX(statement[finalI].getLayoutX() + deltax);
                    statement[finalI].setLayoutY(statement[finalI].getLayoutY() + deltay);

                    if (statement[finalI].getLayoutY() >= 475 || statement[finalI].getLayoutY() <= 0) {
                        deltay = -deltay;
                    }
                    if (statement[finalI].getLayoutX() >= 735 || statement[finalI].getLayoutX() <= 0) {
                        deltax = -deltax;
                    }
                }
            }));
            loop.setCycleCount(Animation.INDEFINITE);
            loop.play();
        }
    }

    Button[] getStatement() {
        return statement;
    }

    Label getQuestionLbl() {
        return questionLbl;
    }

    Label getScoreLbl() {
        return scoreLbl;
    }

    Label getTimeLbl() {
        return timeLbl;
    }

    Label getPlayerNameLbl() {
        return playerNameLbl;
    }
}

