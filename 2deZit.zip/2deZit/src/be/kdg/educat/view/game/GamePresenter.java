package be.kdg.educat.view.game;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.input.MouseEvent;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import be.kdg.educat.model.Model;
import be.kdg.educat.view.highscore.HighScorePresenter;
import be.kdg.educat.view.highscore.HighScoreView;


/**
 * Created by Thomas on 1/08/2017.
 */
public class GamePresenter {
    private GameView view;
    private Timeline timeline;


    public GamePresenter(GameView view) {
        this.view = view;
        setupTimeLine();
        addEventHandlers();
        updateView();
    }

    private void setupTimeLine() {
        timeline = new Timeline();
        timeline.setCycleCount(Animation.INDEFINITE);
        updateClockSpeed();
    }

    private void updateClockSpeed() {
        timeline.getKeyFrames().clear();
        timeline.getKeyFrames().add(new KeyFrame(
                Duration.millis(Model.getInstance().getTickDurationMillis()), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Model.getInstance().tick();
                updateView();
            }
        }
        ));
    }

    private void addEventHandlers() {
        Button[] statements = view.getStatement();
        for (int i = 0; i < statements.length; i++) {
            String answer = statements[i].getText();
            int buttonClicked = i;
            statements[i].setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    Model.getInstance().checkValidAnswer(answer);
                    updateView();
                    if (Model.getInstance().isCorrect()) {
                        statements[buttonClicked].setVisible(false);
                    }
                }
            });
        }
    }

    private void updateView() {
        //Nieuwe question, score toevoegen en tijd toevoegen
        if (Model.getInstance().gameFinished()) {
            showFinishedScore();
            timeline.stop();
        } else {
            this.view.getQuestionLbl().setText(Model.getInstance().getQuestionAsked().get(Model.getInstance().getCurrentQuestionIndex()));
            this.view.getScoreLbl().setText(String.format("%d" + " / " + "%d", Model.getInstance().getScore(), Model.getInstance().getCurrentQuestionIndex()));
            this.view.getTimeLbl().setText(String.format("%d", Model.getInstance().getSeconds()));
        }
    }

    private void showFinishedScore() {
        HighScoreView highScoreView = new HighScoreView(view.getPlayerNameLbl().getText());
        HighScorePresenter presenter = new HighScorePresenter(highScoreView);
        highScoreView.getStylesheets().add("be/kdg/educat/css/Highscore.css");
        view.getScene().setRoot(highScoreView);
    }

    public Timeline getTimeline() {
        return timeline;
    }




}
