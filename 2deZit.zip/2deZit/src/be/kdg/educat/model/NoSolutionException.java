package be.kdg.educat.model;

/**
 * Created by Thomas on 13/08/2017.
 */
public class NoSolutionException extends RuntimeException {
    public NoSolutionException(String message) {
        super(message);
    }
}
