package be.kdg.educat.model;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * Created by Thomas on 9/08/2017.
 */
public class HighScores {
    private ArrayList<Score> scores;
    private final static String FILE = "src/highscores.txt";

    public HighScores() {
        scores = new ArrayList<Score>();
    }

    public void loadHighscore() {
        Path path = Paths.get(FILE);
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE))) {
            String line = null;
            int counter = 0;
            while ((line = reader.readLine()) != null) {
                String[] lijnen = line.split("-");
                scores.add(new Score(lijnen[0], Integer.parseInt(lijnen[1]), Integer.parseInt(lijnen[2])));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveHighscore(String name){
        Model model = Model.getInstance();
        loadHighscore();
        scores.add(new Score(name, model.getScore(), model.getSeconds()));

        Collections.sort(scores);
        if (scores.size() > 10) scores.remove(10);
        try(PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("src/highscores.txt")))) {
            for (Score score : scores)
            pw.write(score.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public ArrayList<Score> getScores() {
        return scores;
    }
}
