package be.kdg.educat.model;

/**
 * Created by Thomas on 13/08/2017.
 */
public class NoDescriptionException extends RuntimeException {
    public NoDescriptionException(String s) {
        super(s);
    }
}
