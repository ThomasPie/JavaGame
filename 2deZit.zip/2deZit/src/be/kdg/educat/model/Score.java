package be.kdg.educat.model;

/**
 * Created by Thomas on 14/08/2017.
 */
public class Score implements Comparable {

    private String name;
    private int score;
    private int seconds;

    public Score(String name, int score, int seconds) {
        this.name = name;
        this.score = score;
        this.seconds = seconds;
    }

    @Override
    public String toString() {
        return name + "-" + score + "-" + seconds + "\n";
    }

    @Override
    public int compareTo(Object o) {
        if (o instanceof Score) {
            Score s = (Score) o;
            if (this.score > s.score) return -1;
            else if (this.score < s.score) return 1;
            else {
                if (this.seconds <= s.seconds) return -1;
                else return 1;
            }
        } else throw new IllegalArgumentException();
    }
}
