package be.kdg.educat;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import be.kdg.educat.model.Model;
import be.kdg.educat.view.start.StartPresenter;
import be.kdg.educat.view.start.StartView;

/**
 * Created by Thomas on 5/07/2017.
 */
public class Main extends Application{
    @Override
    public void start(Stage primaryStage) throws Exception {
        StartView view = new StartView();
        StartPresenter startPresenter = new StartPresenter(Model.getInstance(), view);
        Scene scene = new Scene(view);
        scene.getStylesheets().add("be/kdg/educat/css/Style.css");
        primaryStage.setScene(scene);
        startPresenter.addWindowEventHandlers();
        primaryStage.setTitle("Educat");
        primaryStage.setHeight(700);
        primaryStage.setWidth(850);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
