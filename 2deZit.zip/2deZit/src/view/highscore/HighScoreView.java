package view.highscore;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import model.HighScores;
import model.Score;

import java.util.ArrayList;

/**
 * Created by Thomas on 9/08/2017.
 */
public class HighScoreView extends VBox {
    private Label[] highScoresLbl = new Label[10];
    private ArrayList<Score> scores;
    private HighScores highScores;

    public HighScoreView(){
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes(){

    }

    private void layoutNodes(){
        this.highScores = new HighScores();
        for (int i = 0; i < highScores.getScores().size(); i++) {
            highScoresLbl[i] = new Label();
            highScoresLbl[i].setText(highScores.getScores().get(i-1).getPlayer() + " : " + highScores.getScores().get(i-1).getScore());
        }
        this.setAlignment(Pos.CENTER);
    }
}
