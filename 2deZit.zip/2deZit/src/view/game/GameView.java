package view.game;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.Model;
import model.Speler;


/**
 * Created by Thomas on 5/07/2017.
 */
public class GameView extends BorderPane {
    private Model model;
    private Button[] statement = new Button[7];
    private Label lbl = new Label();
    private Label scoreLbl = new Label();
    private Label timeLbl = new Label();
    private Label playerName = new Label();
    private Speler speler;

    public GameView() {
        this.initialiseNodes();
        this.layoutNodes();
    }

    private void initialiseNodes() {
        this.model = new Model();
        model.leesBestand();
        for (int i = 0; i < 7; i++) {
            this.statement[i] = new Button(model.getPossibleSolutions().get(i));
        }

        this.lbl = new Label(model.getQuestionAsked().get(model.getCurrentQuestionIndex()));
        this.playerName = new Label(speler.getNaam());
        this.scoreLbl = new Label("Score!");
        this.timeLbl = new Label("Time!");
    }

    private void layoutNodes() {
        VBox vbox = new VBox();
        vbox.setPadding(new Insets(20));
        vbox.setSpacing(10);
        vbox.getChildren().addAll(statement);
        vbox.setStyle("-fx-background-color: black");
        this.setCenter(vbox);

        HBox hbox = new HBox();
        hbox.setPadding(new Insets(20));
        hbox.setStyle("-fx-background-color: darkgoldenrod");
        hbox.setSpacing(10);
        hbox.getChildren().add(playerName);
        hbox.getChildren().add(scoreLbl);
        hbox.getChildren().add(timeLbl);
        playerName.setPrefSize(100,40);
        scoreLbl.setPrefSize(100,40);
        timeLbl.setPrefSize(100,40);
        playerName.setAlignment(Pos.CENTER);
        scoreLbl.setAlignment(Pos.CENTER);
        timeLbl.setAlignment(Pos.CENTER);
        hbox.setAlignment(Pos.BASELINE_CENTER);
        this.setTop(hbox);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20));
        hbox1.setStyle("-fx-background-color: darkgoldenrod");
        hbox1.setSpacing(100);
        hbox1.getChildren().add(lbl);
        lbl.setPrefSize(100,40);
        lbl.setAlignment(Pos.CENTER);
        hbox1.setAlignment(Pos.BASELINE_CENTER);
        this.setBottom(hbox1);
    }

    Button[] getStatement() {
        return statement;
    }

    Label getLbl() {
        return lbl;
    }
}

