package view.game;

import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import model.Model;


/**
 * Created by Thomas on 1/08/2017.
 */
public class GamePresenter {
    private GameView view;
    private Model model;

    public GamePresenter(GameView view, Model model) {
        this.view = view;
        this.model = model;
        addEventHandlers();
        updateView();
    }

    private void addEventHandlers(){
        Button[] statements = view.getStatement();
        for (int i = 0; i < statements.length; i++) {
            String answer = statements[i].getText();
            statements[i].setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    model.checkValidAnswer(answer);
                    updateView();
                }
            });
        }
    }

    private void updateView() {
        //Nieuwe question, score toevoegen en tijd toevoegen
        view.getLbl().setText(model.getQuestionAsked().get(model.getCurrentQuestionIndex()));
    }
}
