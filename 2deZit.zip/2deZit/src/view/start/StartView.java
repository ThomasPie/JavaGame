package view.start;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * Created by Thomas on 7/08/2017.
 */
public class StartView extends VBox {
    private Label nameLbl = new Label("Name");
    private TextField playerName = new TextField();
    private ToggleButton[] choice = new ToggleButton[3];
    private Button begin = new Button("Begin the game!");
    private final ToggleGroup tgGroup = new ToggleGroup();

    public StartView() {
        initialiseNodes();
        layoutnodes();
    }

    private void initialiseNodes() {
        playerName.setEditable(true);
        for (int i = 0; i < 3; i++) {
            this.choice[i] = new ToggleButton("Choice " + (i + 1));
            this.choice[i].setToggleGroup(tgGroup);
        }
    }

    private void layoutnodes() {
        this.setStyle("-fx-background-color: black");
        this.setAlignment(Pos.CENTER);

        HBox hBox = new HBox();
        hBox.getChildren().addAll(nameLbl, playerName);
        hBox.setSpacing(50);
        hBox.setPadding(new Insets(50));
        hBox.setAlignment(Pos.CENTER);


        HBox hBox1 = new HBox();
        hBox1.getChildren().addAll(choice);
        hBox1.setSpacing(10);
        hBox1.setPadding(new Insets(20));
        for (int i = 0; i < 3; i++) {
            choice[i].setPrefSize(100,50);
        }
        hBox1.setAlignment(Pos.CENTER);

        HBox hBox2 = new HBox();
        hBox2.getChildren().add(begin);
        hBox2.setPadding(new Insets(20));
        hBox2.setAlignment(Pos.CENTER);

        this.getChildren().addAll(hBox, hBox1,hBox2);
    }

    public TextField getPlayerName() {
        return playerName;
    }

    public ToggleButton[] getChoice() {
        return choice;
    }

    public ToggleGroup getTgGroup() {
        return tgGroup;
    }

    public Button getBegin() {
        return begin;
    }
}
