package view.start;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import model.Model;
import model.Speler;
import view.game.GamePresenter;
import view.game.GameView;

/**
 * Created by Thomas on 7/08/2017.
 */
public class StartPresenter {
    private Model model;
    private StartView startView;
    private Speler speler;

    public StartPresenter(Model model, StartView startView) {
        this.model = new Model();
        this.startView = startView;
        addEventHandlers();
    }

    private void addEventHandlers(){
        startView.getBegin().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                GameView gameView = new GameView();
                GamePresenter gamePresenter = new GamePresenter(gameView,model);
                startView.getScene().setRoot(gameView);
                gameView.getScene().getWindow().sizeToScene();
                speler.naam = (startView.getPlayerName().getText());
            }
        });
    }
}
