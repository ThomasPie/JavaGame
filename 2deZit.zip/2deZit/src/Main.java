import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Model;
import view.game.GamePresenter;
import view.game.GameView;
import view.start.StartPresenter;
import view.start.StartView;

/**
 * Created by Thomas on 5/07/2017.
 */
public class Main extends Application{
    @Override
    public void start(Stage primaryStage) throws Exception {
        //GameView view = new GameView();
        StartView view = new StartView();
        Model model = new Model();
        StartPresenter startPresenter = new StartPresenter(model,view);
        Scene scene = new Scene(view);
        scene.getStylesheets().add("css/Style.css");
        primaryStage.setScene(scene);
        primaryStage.setTitle("Educat");
        primaryStage.setHeight(700);
        primaryStage.setWidth(850);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
